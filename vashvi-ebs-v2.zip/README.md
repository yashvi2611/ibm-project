# Deploy Your Container On Cloud.

## Docker Run

1. Can Choose Images from List
2. Give Name to the Container
3. Host Port Mapping.
5. Detach Mode option.
6. Give number of Replicas that user wants.
    1. based on replica Service or Container will create.
7. Details page where basic information of container is given.    
7. Details page where basic information of service is given.    
8. pull images from docker hub (only public images)
## Deploy Web-App on AWS Ec2

## user can deploy docker container on cloud
# waf-saas
# waf-saas
# waf-saas
